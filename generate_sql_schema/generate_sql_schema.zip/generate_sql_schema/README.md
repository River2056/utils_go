# 使用說明
1. 將以下檔案放在同一個資料夾:
	- generate_sql_schema.exe
	- columns.txt

2. 開啟cmd, 執行前給參數, 以空格隔開
	- ./generate_sql_schema.exe AVQ_DWH_EXAMPLE_TABLE_NAME

3. 參數為欲建立之table名稱

4. columns.txt的內容為: table column name (tab) data type
column name與data type以tab隔開
