# 使用說明
# 使用說明
1. 打開config.json
2. json-file-path為欲搜尋之json檔案路徑(絕對路徑)
3. attr-to-search為欲搜尋之屬性(可多筆)
4. 於cmd中執行./parse_through_json_and_find_attr.exe
5. 結果將輸出: result/result.txt
	- 如果沒有資料則可能該json裡對應屬性為空