# 使用說明
1. 將分散的獨立sql檔放在同一個資料夾
2. 打開cmd 並執行 ./concatenate_sql_files.exe {你的資料夾絕對路徑}
3. 程式會生成result/concatenate_sql.sql, 其結果為所有獨立sql的集合(方便一次執行所有指令)